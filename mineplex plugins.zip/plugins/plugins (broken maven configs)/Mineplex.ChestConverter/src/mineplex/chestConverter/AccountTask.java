package mineplex.chestConverter;

public class AccountTask
{
	public int Id;
	public String Task;
	public String UUID;
}
