package mineplex.core.account;

public interface IQuerylessLoginProcessor
{
	public void processLogin(String playerName, int accountId);
}
