package mineplex.core.account.repository.token;

public class ClientToken
{
    public int AccountId;
    public String Name;
    public String Rank;
    public boolean RankPerm;
    public String RankExpire;
    public int EconomyBalance;
    
    public AccountToken AccountToken;
	public long LastLogin;
}
