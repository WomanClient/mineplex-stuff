package mineplex.core.botspam;

import mineplex.serverdata.commands.ServerCommand;

public class ForceUpdateCommand extends ServerCommand
{
}
