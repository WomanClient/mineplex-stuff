package mineplex.core.antihack.compedaccount;

public enum PriorityCause
{
	JOIN_GAME,
	CHAT
}
