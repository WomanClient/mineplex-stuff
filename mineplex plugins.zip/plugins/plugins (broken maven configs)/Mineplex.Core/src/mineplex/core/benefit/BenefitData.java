package mineplex.core.benefit;

import java.util.HashSet;

public class BenefitData
{
	public HashSet<String> Benefits = new HashSet<String>(); 
	public boolean Loaded = false;
}
