package mineplex.core.achievement;

public class AchievementLog
{
	public long Amount;
	public boolean LevelUp;
	
	public AchievementLog(long amount, boolean levelUp)
	{
		Amount = amount;
		LevelUp = levelUp;
	}
}
