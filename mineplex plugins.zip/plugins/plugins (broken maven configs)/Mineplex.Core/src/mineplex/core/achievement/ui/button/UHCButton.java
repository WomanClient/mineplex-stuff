package mineplex.core.achievement.ui.button;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import mineplex.core.account.CoreClientManager;
import mineplex.core.achievement.AchievementManager;
import mineplex.core.achievement.ui.AchievementShop;
import mineplex.core.achievement.ui.page.UHCMainPage;
import mineplex.core.donation.DonationManager;
import mineplex.core.shop.item.IButton;
import mineplex.core.stats.PlayerStats;
import mineplex.core.stats.StatsManager;

public class UHCButton implements IButton
{
	private AchievementShop _shop;
	private AchievementManager _achievementManager;
	private StatsManager _statsManager;
	private DonationManager _donationManager;
	private CoreClientManager _clientManager;

	private String _targetName;
	private PlayerStats _targetStats;

	public UHCButton(AchievementShop shop, AchievementManager achievementManager, StatsManager statsManager, DonationManager donationManager, CoreClientManager clientManager, String targetName, PlayerStats targetStats)
	{
		_shop = shop;
		_achievementManager = achievementManager;
		_statsManager = statsManager;
		_donationManager = donationManager;
		_clientManager = clientManager;

		_targetName = targetName;
		_targetStats = targetStats;
	}

	@Override
	public void onClick(Player player, ClickType clickType)
	{
		_shop.openPageForPlayer(player, new UHCMainPage(_achievementManager, _statsManager, _shop, _clientManager, _donationManager, "UHC", player, _targetName, _targetStats));
		player.playSound(player.getLocation(), Sound.CLICK, 1, 1);
	}

}
