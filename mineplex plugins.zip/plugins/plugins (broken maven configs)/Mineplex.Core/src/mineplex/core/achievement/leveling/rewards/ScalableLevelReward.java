package mineplex.core.achievement.leveling.rewards;

public interface ScalableLevelReward extends LevelReward
{

	ScalableLevelReward cloneScalable(double scale);

}
