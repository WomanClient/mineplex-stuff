package mineplex.core.chat.repository;

public class ChatSubmitToken
{
	public String player_display_name;
	public String player;
	public String text;
	public String server;
	public String room;
	public String language = "en";
	public String rule;
}
