package mineplex.core.chat.format;

import net.md_5.bungee.api.chat.BaseComponent;

import org.bukkit.entity.Player;

public interface ChatFormatComponent
{

	BaseComponent getText(Player player);

}
