package mineplex.core.chat.repository;

public class ChatEvent
{
	public String id;
	public String message;
}
