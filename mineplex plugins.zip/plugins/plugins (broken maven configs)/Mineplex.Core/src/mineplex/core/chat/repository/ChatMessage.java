package mineplex.core.chat.repository;

public class ChatMessage
{
	public String PlayerName;
	public String Message;
}
