package mineplex.core.chat.repository;

public class ChatClientToken
{

}
