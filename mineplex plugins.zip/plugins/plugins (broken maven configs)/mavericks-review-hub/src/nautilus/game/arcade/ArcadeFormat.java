package nautilus.game.arcade;

import mineplex.core.common.util.C;

/**
 * Copy from {@link nautilus.game.arcade.ArcadeFormat}
 */
public class ArcadeFormat 
{
	public static String Line = C.cDGreen + C.Strike + "=============================================";
}