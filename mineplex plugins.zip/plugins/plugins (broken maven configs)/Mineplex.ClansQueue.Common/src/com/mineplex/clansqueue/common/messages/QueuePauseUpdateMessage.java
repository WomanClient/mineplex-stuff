package com.mineplex.clansqueue.common.messages;

import com.mineplex.clansqueue.common.ClansQueueMessageBody;

public class QueuePauseUpdateMessage extends ClansQueueMessageBody
{
	public String ServerName;
	public boolean Paused;
}