package com.mineplex.clansqueue.common.messages;

import com.mineplex.clansqueue.common.ClansQueueMessageBody;

public class ServerOfflineMessage extends ClansQueueMessageBody
{
	public String ServerName;
}