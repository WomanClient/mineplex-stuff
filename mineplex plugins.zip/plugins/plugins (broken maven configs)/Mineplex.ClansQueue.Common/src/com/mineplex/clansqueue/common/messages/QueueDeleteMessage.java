package com.mineplex.clansqueue.common.messages;

import com.mineplex.clansqueue.common.ClansQueueMessageBody;

public class QueueDeleteMessage extends ClansQueueMessageBody
{
	public String ServerName;
}