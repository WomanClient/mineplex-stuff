package com.mineplex.clansqueue.common.messages;

import com.mineplex.clansqueue.common.ClansQueueMessageBody;

public class QueuePauseBroadcastMessage extends ClansQueueMessageBody
{
	public String ServerName;
	public boolean Paused;
}