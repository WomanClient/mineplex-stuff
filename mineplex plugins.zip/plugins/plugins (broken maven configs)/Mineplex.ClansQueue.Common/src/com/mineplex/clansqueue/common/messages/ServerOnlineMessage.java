package com.mineplex.clansqueue.common.messages;

import com.mineplex.clansqueue.common.ClansQueueMessageBody;

public class ServerOnlineMessage extends ClansQueueMessageBody
{
	public String ServerName;
}