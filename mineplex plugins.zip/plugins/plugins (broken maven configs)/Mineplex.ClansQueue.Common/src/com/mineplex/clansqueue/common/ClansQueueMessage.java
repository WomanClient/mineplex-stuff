package com.mineplex.clansqueue.common;

public class ClansQueueMessage
{
	protected String Origin;
	protected String BodyClass;
	protected String BodySerialized;
}