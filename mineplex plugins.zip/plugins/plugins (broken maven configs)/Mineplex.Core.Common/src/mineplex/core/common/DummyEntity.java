package mineplex.core.common;

import net.minecraft.server.v1_8_R3.Entity;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.World;

public class DummyEntity extends Entity
{
	public DummyEntity(World world)
	{
		super(world);
	}

	@Override
	protected void h()
	{

	}

	@Override
	protected void a(NBTTagCompound nbtTagCompound)
	{

	}

	@Override
	protected void b(NBTTagCompound nbtTagCompound)
	{

	}
}
