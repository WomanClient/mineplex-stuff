package mineplex.core.common.util.particles;

import mineplex.core.common.util.UtilParticle;
import org.bukkit.Location;

public class NormalParticle extends ParticleData
{

	public NormalParticle(UtilParticle.ParticleType particleType, Location location)
	{
		super(particleType, location);
	}

}
