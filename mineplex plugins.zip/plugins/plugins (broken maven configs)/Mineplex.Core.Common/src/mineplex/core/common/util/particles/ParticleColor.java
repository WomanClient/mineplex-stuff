package mineplex.core.common.util.particles;

public abstract class ParticleColor
{

	public abstract float getX();

	public abstract float getY();

	public abstract float getZ();

}
