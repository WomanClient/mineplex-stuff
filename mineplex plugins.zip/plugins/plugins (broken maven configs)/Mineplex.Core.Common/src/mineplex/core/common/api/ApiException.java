package mineplex.core.common.api;

public class ApiException extends Exception
{
}
