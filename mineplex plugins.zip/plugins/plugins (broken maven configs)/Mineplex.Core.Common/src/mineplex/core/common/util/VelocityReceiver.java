package mineplex.core.common.util;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public interface VelocityReceiver 
{
	public void setPlayerVelocity(Player player, Vector velocity);
}
