package mineplex.bungee.api.token;

public class DnsRecord
{
	public int id;
	public String name;
	public String type;
	public String value;
	public String gtdLocation = "DEFAULT";
	public int ttl;
}
