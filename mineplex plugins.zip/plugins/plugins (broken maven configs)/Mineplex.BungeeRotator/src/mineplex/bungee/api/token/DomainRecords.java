package mineplex.bungee.api.token;

import java.util.List;

public class DomainRecords
{
	public List<DnsRecord> data;
	public int page;
	public int totalPage;
	public int totalRecords;
}
